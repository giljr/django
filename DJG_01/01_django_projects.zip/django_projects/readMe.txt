# ReadMe File - For Django Project + VS Code
# Tutorial:

Django version 4.0
Python 3.9.7


How to use (On Terminal):

1- Activate your djangoEnv  -> djangoEnv\Scripts\activate
2- Change to app folder     -> cd first_project
3- run server               -> python manage.py runserver
4- Got To                   -> localhost:8000         output:[Hello, Django! We've got to home website access!]
5- or                       -> localhost:8000/welcome output:[This is my First Django Welcome Page! Welcome!]



System info:

Operating system name:             ->  Microsoft Windows 10 Home Single Language
OS version:                        ->  10.0.19042 N/A compilação 19042
Operating system manufacturer:     ->  Microsoft Corporation
Total physical memory:             ->  8.002 MB

Latest acess:
[27/Dec/2021 15:58:31] "GET /welcome/ HTTP/1.1" 200 46
[27/Dec/2021 15:58:35] "GET / HTTP/1.1" 200 48

version 1.0
author: J3
Date: dec, 2021